package com.example.universidadeESN3.entity;

import lombok.Data;

@Data
public class Professor {
    private Long id;
    private Long matricula;
    private String nome;
}
