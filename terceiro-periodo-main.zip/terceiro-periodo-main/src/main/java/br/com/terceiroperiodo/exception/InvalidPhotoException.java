package br.com.terceiroperiodo.exception;

public class InvalidPhotoException extends RuntimeException{

    public InvalidPhotoException(String message) {
        super(message);
    }

}
